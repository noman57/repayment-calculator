package com.noman.repaymentplanservice.controller;

import com.noman.repaymentplanservice.dto.LoanDTO;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.junit4.SpringRunner;

import java.time.LocalDate;

import static io.restassured.RestAssured.given;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.notNullValue;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class PlanControllerTest
{
    @LocalServerPort
    private int port;


    @Before
    public void setUp()
    {
        RestAssured.port = port;

    }

    @Test
    public void generatePlanShouldReturn() throws Exception
    {
        Response response = given()
            .auth().basic("test", "test")
            .contentType("application/json")
            .body(new LoanDTO(5000, 5.0, 24, LocalDate.parse("2018-01-01")))
            .post("/generate-plan")
            .then()
            .assertThat()
            .statusCode(HttpStatus.OK.value())
            .and()
            .body("$", notNullValue())
            .extract().response();
        final JSONObject result = new JSONObject(response.getBody().asString());
        assertThat(result).isNotNull();
        JSONArray borrowerPayments = result.getJSONArray("borrowerPayments");
        assertThat(borrowerPayments).isNotNull();
        assertThat(borrowerPayments.length()).isEqualTo(24);

    }


    @Test
    public void generatePlanShouldReturnExceptionForInvalidValues() throws Exception
    {
        LoanDTO loanDTO = new LoanDTO();
        Response response = given()
            .contentType("application/json")
            .body(loanDTO)
            .post("/generate-plan")
            .then()
            .assertThat()
            .statusCode(HttpStatus.BAD_REQUEST.value())
            .and()
            .body("$", notNullValue())
            .extract().response();

        final JSONObject errorResult = new JSONObject(response.getBody().asString());
        assertThat(errorResult).isNotNull();
        assertThat(errorResult.getJSONArray("errors").length()).isEqualTo(4);

    }

    @Test
    public void generatePlanShouldReturnExceptionForNullValues() throws Exception
    {

        Response response = given()
            .contentType("application/json")
            .body("{}")
            .post("/generate-plan")
            .then()
            .assertThat()
            .statusCode(HttpStatus.BAD_REQUEST.value())
            .and()
            .body("$", notNullValue())
            .extract().response();

        final JSONObject errorResult = new JSONObject(response.getBody().asString());
        assertThat(errorResult).isNotNull();
        assertThat(errorResult.getJSONArray("errors").length()).isEqualTo(4);

    }
}
