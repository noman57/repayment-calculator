package com.noman.repaymentplanservice.service;

import com.noman.repaymentplanservice.dto.RepaymentDTO;
import com.noman.repaymentplanservice.dto.LoanDTO;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import java.time.LocalDate;
import java.util.List;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

@RunWith(MockitoJUnitRunner.class)
class RepaymentGeneratorServiceTest
{

    private  RepaymentGeneratorService repaymentGeneratorService = new RepaymentGeneratorService();



    @Test
    void calculatePaymentPlan()
    {
        List<RepaymentDTO> installmentDTOS = repaymentGeneratorService
            .calculatePaymentPlan(new LoanDTO(5000, 5.0, 24, LocalDate.parse("2018-01-01")));
        assertThat(installmentDTOS.size()).isEqualTo(24);
        RepaymentDTO repaymentDTO = installmentDTOS.get(23);
        assertThat(repaymentDTO.getInitialOutstandingPrincipal()).isEqualTo(5000);
        assertThat(repaymentDTO.getDate()).isEqualTo(LocalDate.parse("2019-12-01"));
        assertThat(repaymentDTO.getInterest()).isEqualTo(0.91);
        assertThat(repaymentDTO.getPrinciple()).isEqualTo(218.37);
    }


    @Test
    void calculateAnnuity()
    {
        double annuity = repaymentGeneratorService
            .calculateAnnuity(new LoanDTO(5000, 5.0, 24, LocalDate.parse("2018-01-01")));
        assertThat(annuity).isEqualTo(219.36);
    }

}
