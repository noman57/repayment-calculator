package com.noman.repaymentplanservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RepaymentplanserviceApplicationTests {



}
