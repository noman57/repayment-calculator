package com.noman.repaymentplanservice.service;

import com.noman.repaymentplanservice.dto.LoanDTO;
import com.noman.repaymentplanservice.dto.RepaymentDTO;
import org.springframework.stereotype.Service;

import javax.validation.Valid;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.LinkedList;
import java.util.List;


@Service
public class RepaymentGeneratorService
{



    public List<RepaymentDTO> calculatePaymentPlan( @Valid LoanDTO loanDTO)
    {
        double loanRemaining=loanDTO.getLoanAmount();
        double annuity= calculateAnnuity(loanDTO);
        LocalDate paymentDate = loanDTO.getStartDate();
        List<RepaymentDTO> repaymentPlans = new LinkedList<>();

        while(loanRemaining>0){

            double interest = calculateMonthlyInterest(loanDTO, loanRemaining);
            double principle=getRoundValue(annuity-interest);
            if(principle>=loanRemaining){
                principle=loanRemaining;
                annuity=loanRemaining+interest;
            }
            loanRemaining=getRoundValue(loanRemaining-principle);
            RepaymentDTO repaymentDTO = mapToRepaymentDTO(loanDTO.getLoanAmount(), loanRemaining, annuity, paymentDate, interest, principle);
            paymentDate= paymentDate.plusMonths(1);
            repaymentPlans.add(repaymentDTO);
        }
        return repaymentPlans;
    }


    private double calculateMonthlyInterest(@Valid LoanDTO loanDTO, double loanRemaining)
    {
        return getRoundValue(  (30 * loanRemaining * loanDTO.getNominalRate()) / (360 * 100));
    }


    private RepaymentDTO mapToRepaymentDTO( double totalLoan, double loanRemaining, double annuity,
        LocalDate paymentDate, double interest, double principle)
    {
        RepaymentDTO repaymentDTO = new RepaymentDTO();
        repaymentDTO.setBorrowerPaymentAmount(annuity);
        repaymentDTO.setDate(paymentDate);
        repaymentDTO.setInitialOutstandingPrincipal(totalLoan);
        repaymentDTO.setPrinciple(principle);
        repaymentDTO.setInterest(interest);
        repaymentDTO.setRemainingOutstandingPrincipal(loanRemaining);
        return repaymentDTO;
    }


    double calculateAnnuity(LoanDTO loanDTO){
        double interestPerMonth=loanDTO.getNominalRate()/(12*100);
        double formulaPart1=loanDTO.getLoanAmount()*interestPerMonth;
        double formulaPart2 =1- Math.pow((1 + interestPerMonth) , -loanDTO.getDuration());
        return getRoundValue(formulaPart1/formulaPart2);
    }

    private double getRoundValue(double interestVal)
    {
        return new BigDecimal(interestVal).setScale(2, RoundingMode.HALF_UP).doubleValue();
    }

}
