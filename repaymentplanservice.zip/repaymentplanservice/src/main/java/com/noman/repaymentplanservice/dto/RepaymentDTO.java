package com.noman.repaymentplanservice.dto;

import java.time.LocalDate;

public class RepaymentDTO
{

    private double borrowerPaymentAmount;

    private LocalDate date;

    private double initialOutstandingPrincipal;

    private double interest;

    private  double principle;

    private double remainingOutstandingPrincipal;


    public double getBorrowerPaymentAmount()
    {
        return borrowerPaymentAmount;
    }


    public void setBorrowerPaymentAmount(double borrowerPaymentAmount)
    {
        this.borrowerPaymentAmount = borrowerPaymentAmount;
    }


    public LocalDate getDate()
    {
        return date;
    }


    public void setDate(LocalDate date)
    {
        this.date = date;
    }


    public double getInitialOutstandingPrincipal()
    {
        return initialOutstandingPrincipal;
    }


    public void setInitialOutstandingPrincipal(double initialOutstandingPrincipal)
    {
        this.initialOutstandingPrincipal = initialOutstandingPrincipal;
    }


    public double getInterest()
    {
        return interest;
    }


    public void setInterest(double interest)
    {
        this.interest = interest;
    }


    public double getPrinciple()
    {
        return principle;
    }


    public void setPrinciple(double principle)
    {
        this.principle = principle;
    }


    public double getRemainingOutstandingPrincipal()
    {
        return remainingOutstandingPrincipal;
    }


    public void setRemainingOutstandingPrincipal(double remainingOutstandingPrincipal)
    {
        this.remainingOutstandingPrincipal = remainingOutstandingPrincipal;
    }
}
