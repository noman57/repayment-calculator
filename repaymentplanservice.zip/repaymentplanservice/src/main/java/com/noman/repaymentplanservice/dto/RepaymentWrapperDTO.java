package com.noman.repaymentplanservice.dto;

import java.util.List;

public class RepaymentWrapperDTO
{

    private List<RepaymentDTO> borrowerPayments;


    public RepaymentWrapperDTO(List<RepaymentDTO> borrowerPayments)
    {
        this.borrowerPayments = borrowerPayments;
    }


    public List<RepaymentDTO> getBorrowerPayments()
    {
        return borrowerPayments;
    }
}
