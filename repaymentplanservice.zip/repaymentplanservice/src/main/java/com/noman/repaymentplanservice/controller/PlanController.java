package com.noman.repaymentplanservice.controller;

import com.noman.repaymentplanservice.dto.LoanDTO;
import com.noman.repaymentplanservice.dto.RepaymentWrapperDTO;
import com.noman.repaymentplanservice.service.RepaymentGeneratorService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

@RestController
public class PlanController
{


    private final RepaymentGeneratorService repaymentGeneratorService;

    public PlanController(RepaymentGeneratorService repaymentGeneratorService)
    {
        this.repaymentGeneratorService = repaymentGeneratorService;
    }


    @PostMapping("/generate-plan")
    public ResponseEntity<RepaymentWrapperDTO> calculateRepaymentPlan(@Valid @RequestBody LoanDTO loanDTO){
        return ResponseEntity.ok(new RepaymentWrapperDTO(repaymentGeneratorService.calculatePaymentPlan(loanDTO)));
    }
}
