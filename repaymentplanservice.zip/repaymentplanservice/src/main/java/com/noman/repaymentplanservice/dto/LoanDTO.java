package com.noman.repaymentplanservice.dto;

import javax.validation.constraints.DecimalMin;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;

public class LoanDTO
{
    @NotNull(message = "loan amount field  can not be empty")
    @DecimalMin(value = "0.01", message = "loan amount field must be positive")
    private double loanAmount;

    @NotNull(message = "nominal rate field can not be empty")
    @DecimalMin(value = "0.01", message = "nominal rate field must be positive")
    private double nominalRate;

    @NotNull(message = "duration field  can not be empty")
    @Min(value = 1, message = "duration field  must be positive")
    private int duration;

    @NotNull(message = "start date field  can not be empty")
    private LocalDate startDate;

    public LoanDTO()
    {
    }

    public LoanDTO(double loanAmount, double nominalRate, int duration, LocalDate startDate)
    {
        this.loanAmount = loanAmount;
        this.nominalRate = nominalRate;
        this.duration = duration;
        this.startDate = startDate;
    }


    public double getLoanAmount()
    {
        return loanAmount;
    }


    public double getNominalRate()
    {
        return nominalRate;
    }


    public int getDuration()
    {
        return duration;
    }


    public LocalDate getStartDate()
    {
        return startDate;
    }


    public void setLoanAmount(double loanAmount)
    {
        this.loanAmount = loanAmount;
    }


    public void setNominalRate(double nominalRate)
    {
        this.nominalRate = nominalRate;
    }


    public void setDuration(int duration)
    {
        this.duration = duration;
    }


    public void setStartDate(LocalDate startDate)
    {
        this.startDate = startDate;
    }
}
