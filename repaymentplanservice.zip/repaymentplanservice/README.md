# Repayment plan calculation

## Task Description

* Java 11
* Spring Boot
* spring eureka client
* Maven


## Description
 * It takes four original params as input and returns.
 * Validations were also added.
 * Api can be consumed as rest service
 * Port 8181 is server port
 * run application with command `mvn spring-boot:run`
 * To avoid complications security implementation was not added
 * Eureka client is available and application can directly be connected to microservice architecture. Please change  in property file to point to the right port. 
 * Locale date was used for date selection. 
 * More Test does not necessary mean good test. Test covers all the paths required.
   

## Would Have like to add 
* Spring security 
* More edge case test
* During weekend would have a bit more relaxing 

